﻿using Yatzy_Bibliotek;

class Tester
{
    static void Main(string[] args) 
    {
        //Enere tester:
        Console.WriteLine("Enere test: forventet resultat: 2. Resultat: " + PoengBibliotek.Poengsum("3, 2, 1, 1, 5", PoengBibliotek.Kategorier.Enere));
        Console.WriteLine("Enere test: forventet resultat: -1 (error). Resultat: " + PoengBibliotek.Poengsum("3,2,1,1,5", PoengBibliotek.Kategorier.Enere));

        //Toere tester:
        Console.WriteLine("Toere test: forventet resultat: 0. Resultat: " + PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.Toere));

        //Treere tester:
        Console.WriteLine("Treere test: forventet resultat: 9. Resultat: " + PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.Treere));

        //Firere tester
        Console.WriteLine("Firere test: forventet resultat: 4. Resultat: " + PoengBibliotek.Poengsum("3, 3, 4, 5, 5", PoengBibliotek.Kategorier.Firere));

        //Femere tester:
        Console.WriteLine("Femere test: forventet resultat: 10. Resultat: " + PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.Femmere));

        //Seksere tester:
        Console.WriteLine("Seksere test: forventet resultat: 12. Resultat: " + PoengBibliotek.Poengsum("6, 3, 6, 5, 5", PoengBibliotek.Kategorier.Seksere));

        //Par tester:
        Console.WriteLine("Par test: forventet resultat: 10. Resultat: " + PoengBibliotek.Poengsum("3, 3, 6, 5, 5", PoengBibliotek.Kategorier.Par));

        //ToPar tester:
        Console.WriteLine("ToPar test: forventet resultat: 16. Resultat: " + PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.ToPar));

        //TreLike tester:
        Console.WriteLine("TreLike test: forventet resultat: 15. Resultat: " + PoengBibliotek.Poengsum("3, 3, 5, 5, 5", PoengBibliotek.Kategorier.TreLike));

        //FireLike tester:
        Console.WriteLine("FireLike test: forventet resultat: 20. Resultat: " + PoengBibliotek.Poengsum("3, 5, 5, 5, 5", PoengBibliotek.Kategorier.FireLike));

        //LitenStraight tester:
        Console.WriteLine("LitenStraight test: forventet resultat: 15. Resultat: " + PoengBibliotek.Poengsum("1, 2, 3, 4, 5", PoengBibliotek.Kategorier.LitenStraight));

        //StorStraight tester:
        Console.WriteLine("StorStraight test: forventet resultat: 20. Resultat: " + PoengBibliotek.Poengsum("6, 2, 4, 3, 5", PoengBibliotek.Kategorier.StorStraight));

        //FulltHus tester:
        Console.WriteLine("FulltHus test: forventet resultat: 19. Resultat: " + PoengBibliotek.Poengsum("3, 3, 3, 5, 5", PoengBibliotek.Kategorier.FulltHus));
        Console.WriteLine("FulltHus test 2: forventet resultat: 0. Resultat: " + PoengBibliotek.Poengsum("3, 3, 3, 3, 5", PoengBibliotek.Kategorier.FulltHus));

        //Sjanse tester:
        Console.WriteLine("Sjanse test: forventet resultat: 17. Resultat: " + PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.Sjanse));

        //Yatzy tester:
        Console.WriteLine("Yatzy test: forventet resultat: 50. Resultat: " + PoengBibliotek.Poengsum("3, 3, 3, 3, 3", PoengBibliotek.Kategorier.Yatzy));
        Console.WriteLine("Yatzy test 2: forventet resultat: 0. Resultat: " + PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.Yatzy));
    }
}