﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Yatzy_Bibliotek;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yatzy_Bibliotek.Tests
{
    [TestClass()]
    public class PoengBibliotekTests
    {
        [TestMethod()]
        public void DårligStrengTest() {
            Assert.AreEqual(-1, PoengBibliotek.Poengsum("3,2,1,1,5", PoengBibliotek.Kategorier.Enere));
        }
        [TestMethod()]
        public void kortStrengTest() {
            Assert.AreEqual(-1, PoengBibliotek.Poengsum("3,2,1,1", PoengBibliotek.Kategorier.Enere));
        }
        [TestMethod()]
        public void EnereTest() {
            Assert.AreEqual(2, PoengBibliotek.Poengsum("3, 2, 1, 1, 5", PoengBibliotek.Kategorier.Enere));
        }
        [TestMethod()]
        public void ToereTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 1, 1, 5", PoengBibliotek.Kategorier.Toere));
        }
        [TestMethod()]
        public void TreereTest() {
            Assert.AreEqual(9, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.Treere));
        }
        [TestMethod()]
        public void FirereTest() {
            Assert.AreEqual(8, PoengBibliotek.Poengsum("4, 3, 4, 3, 5", PoengBibliotek.Kategorier.Firere));
        }
        [TestMethod()]
        public void FemereTest() {
            Assert.AreEqual(5, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.Femmere));
        }
        [TestMethod()]
        public void SeksereTest() {
            Assert.AreEqual(30, PoengBibliotek.Poengsum("6, 6, 6, 6, 6", PoengBibliotek.Kategorier.Seksere));
        }
        [TestMethod()]
        public void ErParTest() {
            Assert.AreEqual(10, PoengBibliotek.Poengsum("3, 3, 4, 5, 5", PoengBibliotek.Kategorier.Par));
        }
        [TestMethod()]
        public void IkkeParTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.Par));
        }
        [TestMethod()]
        public void ErToParTest() {
            Assert.AreEqual(18, PoengBibliotek.Poengsum("3, 3, 4, 6, 6", PoengBibliotek.Kategorier.ToPar));
        }
        [TestMethod()]
        public void IkkeToParTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.ToPar));
        }
        [TestMethod()]
        public void ErTreLikeTest() {
            Assert.AreEqual(9, PoengBibliotek.Poengsum("3, 3, 4, 3, 6", PoengBibliotek.Kategorier.TreLike));
        }
        [TestMethod()]
        public void IkkeTreLikeTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 2, 6", PoengBibliotek.Kategorier.TreLike));
        }
        [TestMethod()]
        public void ErFireLikeTest() {
            Assert.AreEqual(12, PoengBibliotek.Poengsum("3, 3, 3, 3, 5", PoengBibliotek.Kategorier.FireLike));
        }
        [TestMethod()]
        public void IkkeFireLikeTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 1, 4, 3, 5", PoengBibliotek.Kategorier.FireLike));
        }
        [TestMethod()]
        public void ErLitenStraightTest() {
            Assert.AreEqual(15, PoengBibliotek.Poengsum("1, 3, 4, 2, 5", PoengBibliotek.Kategorier.LitenStraight));
        }
        [TestMethod()]
        public void IkkeLitenStraightTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.LitenStraight));
        }
        [TestMethod()]
        public void ErStorStraightTest() {
            Assert.AreEqual(20, PoengBibliotek.Poengsum("6, 2, 4, 3, 5", PoengBibliotek.Kategorier.StorStraight));
        }
        [TestMethod()]
        public void IkkeStorStraightTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 3, 5", PoengBibliotek.Kategorier.StorStraight));
        }
        [TestMethod()]
        public void ErFulltHusTest() {
            Assert.AreEqual(19, PoengBibliotek.Poengsum("3, 3, 3, 5, 5", PoengBibliotek.Kategorier.FulltHus));
        }
        [TestMethod()]
        public void IkkeFulltHusTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 5, 5", PoengBibliotek.Kategorier.FulltHus));
        }
        [TestMethod()]
        public void SjanseTest() {
            Assert.AreEqual(17, PoengBibliotek.Poengsum("3, 3, 1, 5, 5", PoengBibliotek.Kategorier.Sjanse));
        }
        [TestMethod()]
        public void ErYatzyTest() {
            Assert.AreEqual(50, PoengBibliotek.Poengsum("3, 3, 3, 3, 3", PoengBibliotek.Kategorier.Yatzy));
        }
        [TestMethod()]
        public void IkkeYatzyTest() {
            Assert.AreEqual(0, PoengBibliotek.Poengsum("3, 3, 4, 3, 3", PoengBibliotek.Kategorier.Yatzy));
        }
        [TestMethod()]
        public void HoyestePoengKategoriTest() {
            Assert.AreEqual("Kategori: Sjanse. Poengsum: 16", PoengBibliotek.HoyestePoengKategori("3, 3, 4, 3, 3"));
        }
        [TestMethod()]
        public void HoyestePoengKategoriTest2() {
            Assert.AreEqual("Kategori: Yatzy. Poengsum: 50", PoengBibliotek.HoyestePoengKategori("3, 3, 3, 3, 3"));
        }
        [TestMethod()]
        public void HoyestePoengKategoriErrorTest() {
            Assert.AreEqual("Error. fikk ikke riktig terningkast", PoengBibliotek.HoyestePoengKategori("3, 3, 3, 3"));
        }
        [TestMethod()]
        public void HoyestePoengKategoriErrorTest2() {
            Assert.AreEqual("Error. fikk ikke riktig terningkast", PoengBibliotek.HoyestePoengKategori("3,3,3,3,5"));
        }
    }
}