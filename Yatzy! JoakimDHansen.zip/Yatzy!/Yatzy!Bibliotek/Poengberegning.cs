﻿namespace Yatzy_Bibliotek
{
    public static class PoengBibliotek
    {
        public enum Kategorier {
            Enere,
            Toere,
            Treere,
            Firere,
            Femmere,
            Seksere,
            Par,
            ToPar,
            TreLike,
            FireLike,
            LitenStraight,
            StorStraight,
            FulltHus,
            Sjanse,
            Yatzy
        }
        private static Dictionary<int, int> StrengTilDict(string terningkast) {
            List<int> terningerListe = new List<int>();
            foreach(string terning in terningkast.Split(", ")) {
                try {
                    int kast = int.Parse(terning);
                    terningerListe.Add(kast);
                }
                catch (Exception) {
                    Console.WriteLine("Kunne ikke lese terningkast til int");
                    return null;
                }
            }
            if(terningerListe.Count() != 5) {
                Console.WriteLine("Ikke riktig mengde terninger i terningkast");
                return null;
            }
            Dictionary<int, int> terninger = new Dictionary<int, int>();
            foreach(int terning in terningerListe) {
                if (!terninger.ContainsKey(terning)) {
                    terninger.Add(terning, 1);
                }
                else {
                    terninger.TryGetValue(terning, out int antallKast);
                    terninger[terning] = antallKast + 1;
                }
            }
            return terninger;
        }
        /// <summary>
        /// Gitt en streng med 5 tall og en kategori vil returnere en int av poengsummen av terningkastet i den kategorien du valgte.
        /// en return av -1 betyr at noe gikk feil.
        /// </summary>
        /// <param name="terningkast">Streng med 5 tall separert med en ", "</param>
        /// <param name="kategori">Bruk Kategorier enumen fra dette biblioteket her</param>
        /// <returns>Returnerer en int</returns>
        public static int Poengsum(string terningkast, Kategorier kategori) {
            Dictionary<int, int> terninger = StrengTilDict(terningkast);
            if(terninger == null) {
                return -1;
            }
            switch (kategori) {
                case Kategorier.Enere:
                    return Enere(terninger);
                case Kategorier.Toere:
                    return Toere(terninger);
                case Kategorier.Treere:
                    return Treere(terninger);
                case Kategorier.Firere:
                    return Firere(terninger);
                case Kategorier.Femmere:
                    return Femmere(terninger);
                case Kategorier.Seksere:
                    return Seksere(terninger);
                case Kategorier.Par:
                    return Par(terninger);
                case Kategorier.ToPar:
                    return ToPar(terninger);
                case Kategorier.TreLike:
                    return TreLike(terninger);
                case Kategorier.FireLike:
                    return FireLike(terninger);
                case Kategorier.LitenStraight:
                    return LitenStraight(terninger);
                case Kategorier.StorStraight:
                    return StorStraight(terninger);
                case Kategorier.FulltHus:
                    return FulltHus(terninger);
                case Kategorier.Sjanse:
                    return Sjanse(terninger);
                case Kategorier.Yatzy:
                    return Yatzy(terninger);
                default:
                    Console.WriteLine("Kategorien finnes ikke");
                    return -1;
            }
        }
        /// <summary>
        /// Gitt en streng med 5 tall vil returnere en streng som inneholder kategorien som gir mest poeng og hvor mange poeng den kategorien gir. 
        /// </summary>
        /// <param name="terningkast">Streng med 5 tall separert med en ", "</param>
        /// <returns>Returnerer en streng </returns>
        public static string HoyestePoengKategori(string terningkast) {
            Dictionary<int, int> terninger = StrengTilDict(terningkast);
            if (terninger == null) {
                return "Error. fikk ikke riktig terningkast";
            }
            else if (terninger.Count == 1) {
                return "Kategori: Yatzy. Poengsum: 50";
            }
            return "Kategori: Sjanse. Poengsum: " + Sjanse(terninger);
        }
        private static int Enere(Dictionary<int, int> terningkast) {
            terningkast.TryGetValue(1, out int antallKast);
            return antallKast;
        }
        private static int Toere(Dictionary<int, int> terningkast) {
            terningkast.TryGetValue(2, out int antallKast);
            return antallKast * 2;
        }
        private static int Treere(Dictionary<int, int> terningkast) {
            terningkast.TryGetValue(3, out int antallKast);
            return antallKast * 3;
        }
        private static int Firere(Dictionary<int, int> terningkast) {
            terningkast.TryGetValue(4, out int antallKast);
            return antallKast * 4;
        }
        private static int Femmere(Dictionary<int, int> terningkast) {
            terningkast.TryGetValue(5, out int antallKast);
            return antallKast * 5;
        }
        private static int Seksere(Dictionary<int, int> terningkast) {
            if(terningkast.TryGetValue(6, out int antallKast));
            return antallKast * 6;
        }
        private static int Par(Dictionary<int, int> terningkast) {
            if (terningkast.ContainsValue(2)) {
                foreach (KeyValuePair<int, int> terning in terningkast.OrderByDescending(key => key.Key)) {
                    if (terning.Value == 2) {
                        return (terning.Key * terning.Value);
                    }
                }
            }
            return 0;
        }
        private static int ToPar(Dictionary<int, int> terningkast) {
            int sum = 0;
            if (terningkast.Count == 3 && terningkast.ContainsValue(2)) { //hvis det er tre Key/Value par og en av dem har er verdi av to så må vi ha to par.
                foreach (KeyValuePair<int, int> terning in terningkast) {
                    if(terning.Value == 2) {
                        sum += (terning.Key * terning.Value);
                    }
                }
            }
            return sum;
        }
        private static int TreLike(Dictionary<int, int> terningkast) {
            if (terningkast.ContainsValue(3)) { //hvis en av terningkastene har er verdi av tre så må vi ha tre like.
                foreach (KeyValuePair<int, int> terning in terningkast) {
                    if (terning.Value >= 3) {
                        return (terning.Key * 3);
                    }
                }
            }
            return 0;
        }
        private static int FireLike(Dictionary<int, int> terningkast) {
            if (terningkast.ContainsValue(4)) { //hvis en av terningkastene har er verdi av fire så må vi ha fire like.
                foreach (KeyValuePair<int, int> terning in terningkast) {
                    if (terning.Value >= 4) { 
                        return (terning.Key * 4);
                    }
                }
            }
            return 0;
        }
        private static int LitenStraight(Dictionary<int, int> terningkast) {
            if (terningkast.Count == 5 && terningkast.Keys.Max() == 5) { //hvis det er fem Key/Value par og største Key er 5 så må vi ha Liten Straight.
                return 15; 
            }
            return 0;
        }
        private static int StorStraight(Dictionary<int, int> terningkast) {
            if (terningkast.Count == 5 && terningkast.Keys.Min() == 2) { //hvis det er fem Key/Value par og minste Key er 2 så må vi ha Stor Straight.
                return 20; // må summere sammen her
            }
            return 0;
        }
        private static int FulltHus(Dictionary<int, int> terningkast) {
            int sum = 0;
            if (terningkast.Count == 2 && terningkast.Values.Max() == 3) { //hvis det er to Key/Value par og høyeste verdi er 3 så må vi ha fullt hus.
                foreach (KeyValuePair<int, int> terning in terningkast) {
                    sum += (terning.Key * terning.Value);
                }
            }
            return sum;
        }
        private static int Sjanse(Dictionary<int, int> terningkast) {
            int sum = 0;
            foreach (KeyValuePair<int, int> terning in terningkast) { 
                sum += (terning.Key * terning.Value);
            }
            return sum;
        }
        private static int Yatzy(Dictionary<int, int> terningkast) {
            if (terningkast.Count == 1) { //hvis det bare er et Key/Value par så må alle terningene være lik.
                return 50;
            }
            return 0;
        }
    }
}